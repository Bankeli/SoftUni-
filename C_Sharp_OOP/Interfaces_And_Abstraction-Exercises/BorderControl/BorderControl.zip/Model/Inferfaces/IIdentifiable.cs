﻿
namespace BorderControl.Model.Inferfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
