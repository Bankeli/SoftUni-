﻿namespace MusicLibrary
{
    public class MusicLibrary
    {
        
    }
}
