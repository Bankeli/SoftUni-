﻿namespace MusicLibrary
{
    public class Track
    {
        
    }
}
